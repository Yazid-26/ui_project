import React from "react";
import { Rectangle } from "../../components/Rectangle";
import "./style.css";

export const MacbookPro = () => {
  return (
    <div className="macbook-pro">
      <div className="overlap-group-wrapper">
        <div className="overlap-group">
          <div className="frame">
            <img className="gear-machine" alt="Gear machine" src="/img/gear-machine-background-free-vector-1.png" />
          </div>
          <div className="job-card-table" />
          <div className="text-wrapper">JOBS</div>
          <div className="div">
            <div className="text-wrapper-2">OVERDUE JOBS</div>
            <h1 className="element">
              <span className="span">37</span>
              <span className="text-wrapper-3">NOS</span>
            </h1>
          </div>
          <div className="frame-2">
            <div className="text-wrapper-4">NEW JOB</div>
            <div className="element-NOS">
              <span className="text-wrapper-5">2</span>
              <span className="text-wrapper-6">&nbsp;</span>
              <span className="text-wrapper-7">NOS</span>
            </div>
          </div>
          <div className="frame-3">
            <div className="text-wrapper-8">TODAY COMPLETED</div>
            <div className="element-NOS-2">
              <span className="text-wrapper-9">2</span>
              <span className="text-wrapper-10">&nbsp;</span>
              <span className="text-wrapper-11">NOS</span>
            </div>
          </div>
          <div className="frame-4">
            <div className="text-wrapper-12">TOP SERVICE ENGINEER</div>
            <div className="element-NOS-3">
              <span className="text-wrapper-13">2 </span>
              <span className="text-wrapper-14">NOS</span>
            </div>
          </div>
          <div className="frame-5">
            <img className="add-job-sheet-icons" alt="Add job sheet icons" src="/img/import-job-sheet-icons.svg" />
            <div className="text-wrapper-15">Add Job Sheet</div>
          </div>
          <div className="frame-6">
            <img className="excel-icons" alt="Excel icons" src="/img/excel-icons.svg" />
            <div className="text-wrapper-16">Excel</div>
          </div>
          <div className="frame-7">
            <img className="import-job-sheet" alt="Import job sheet" src="/img/import-job-sheet-icons.svg" />
            <div className="text-wrapper-17">Import Job Sheet</div>
          </div>
          <div className="div-wrapper">
            <div className="text-wrapper-18">Advance Seach</div>
          </div>
          <div className="frame-8">
            <div className="text-wrapper-19">Seach</div>
          </div>
          <div className="p-wrapper">
            <p className="p">Job No / Name / Email / Mobile / Vechicle</p>
          </div>
          <div className="frame-9">
            <div className="text-wrapper-20">From</div>
            <img className="vector" alt="Vector" src="/img/vector-10.svg" />
          </div>
          <div className="frame-10">
            <div className="text-wrapper-21">To</div>
            <img className="img" alt="Vector" src="/img/vector-10.svg" />
          </div>
          <div className="frame-11">
            <div className="text-wrapper-22">All Status</div>
            <img className="list-box" alt="List box" src="/img/list-box-1.svg" />
          </div>
          <div className="frame-12">
            <div className="text-wrapper-23">All Status</div>
            <img className="list-box-2" alt="List box" src="/img/list-box.svg" />
          </div>
          <div className="rectangle-2" />
          <img className="line" alt="Line" src="/img/line-25.svg" />
          <div className="frame-13">
            <div className="frame-14">
              <Rectangle
                property1="default"
                style={{
                  height: "12.02px",
                  minWidth: "12px",
                  position: "relative",
                  width: "unset",
                }}
              />
              <div
                className="component"
                style={{
                  backgroundImage: "url(/img/vector-12.svg)",
                }}
              />
              <div className="vector-wrapper">
                <img className="vector-2" alt="Vector" src="/img/vector-14.svg" />
              </div>
              <div
                className="component-2"
                style={{
                  backgroundImage: "url(/img/vector-16.svg)",
                }}
              />
            </div>
            <div className="frame-15">
              <div className="text-wrapper-24">ONGOING</div>
              <div className="frame-16">
                <div className="ellipse" />
                <div className="text-wrapper-25">10</div>
              </div>
            </div>
            <div className="frame-17">
              <div className="text-wrapper-26">ALL JOB CARDS</div>
              <div className="frame-18">
                <div className="ellipse-2" />
                <div className="text-wrapper-27">90</div>
              </div>
            </div>
            <div className="frame-19">
              <div className="text-wrapper-28">COMPLETED</div>
              <div className="frame-20">
                <div className="ellipse-3" />
                <div className="text-wrapper-29">70</div>
              </div>
            </div>
            <div className="frame-21">
              <p className="text-wrapper-30">Displaying 1-26 of 26 results</p>
            </div>
          </div>
          <img className="line-2" alt="Line" src="/img/line-24.svg" />
          <div className="rectangle-wrapper">
            <Rectangle
              property1="default"
              style={{
                height: "12.02px",
                minWidth: "12px",
                position: "relative",
                width: "unset",
              }}
            />
          </div>
          <Rectangle
            property1="default"
            style={{
              left: "99px",
              position: "absolute",
              top: "671px",
            }}
          />
          <Rectangle
            property1="default"
            style={{
              left: "99px",
              position: "absolute",
              top: "746px",
            }}
          />
          <Rectangle
            property1="default"
            style={{
              left: "99px",
              position: "absolute",
              top: "821px",
            }}
          />
          <Rectangle
            property1="default"
            style={{
              left: "99px",
              position: "absolute",
              top: "896px",
            }}
          />
          <Rectangle
            property1="default"
            style={{
              left: "99px",
              position: "absolute",
              top: "971px",
            }}
          />
          <Rectangle
            property1="default"
            style={{
              left: "99px",
              position: "absolute",
              top: "1046px",
            }}
          />
          <div className="frame-22">
            <div className="text-wrapper-31">Status</div>
            <img className="status-icons" alt="Status icons" src="/img/est-total-icons.svg" />
          </div>
          <div className="frame-23">
            <div className="text-wrapper-32">OVERDUE</div>
          </div>
          <div className="frame-24">
            <div className="text-wrapper-33">SCHEDULED</div>
          </div>
          <div className="frame-25">
            <div className="text-wrapper-34">OVERDUE</div>
          </div>
          <div className="frame-26">
            <div className="text-wrapper-35">OVERDUE</div>
          </div>
          <div className="frame-27">
            <div className="text-wrapper-36">OVERDUE</div>
          </div>
          <div className="frame-28">
            <div className="text-wrapper-37">OVERDUE</div>
          </div>
          <div className="frame-29">
            <div className="text-wrapper-38">Job #</div>
            <img className="job-icons" alt="Job icons" src="/img/est-total-icons.svg" />
          </div>
          <div className="admin-dec-wrapper">
            <p className="admin-dec">
              <span className="text-wrapper-39">
                Admin - 120#
                <br />
              </span>
              <span className="text-wrapper-40">Dec 02, 2019 </span>
            </p>
          </div>
          <div className="vijay-dec-wrapper">
            <p className="vijay-dec">
              <span className="text-wrapper-41">
                vijay - 126#
                <br />
              </span>
              <span className="text-wrapper-42">Dec 02, 2019 </span>
            </p>
          </div>
          <div className="frame-30">
            <p className="admin-dec-2">
              <span className="text-wrapper-43">
                Admin - 120#
                <br />
              </span>
              <span className="text-wrapper-44">Dec 02, 2019 </span>
            </p>
          </div>
          <div className="frame-31">
            <p className="admin-dec-3">
              <span className="text-wrapper-45">
                Admin - 120#
                <br />
              </span>
              <span className="text-wrapper-46">Dec 02, 2019 </span>
            </p>
          </div>
          <div className="frame-32">
            <p className="admin-dec-4">
              <span className="text-wrapper-47">
                Admin - 120#
                <br />
              </span>
              <span className="text-wrapper-48">Dec 02, 2019 </span>
            </p>
          </div>
          <div className="frame-33">
            <p className="admin-dec-5">
              <span className="text-wrapper-49">
                Admin - 120#
                <br />
              </span>
              <span className="text-wrapper-50">Dec 02, 2019 </span>
            </p>
          </div>
          <div className="frame-34">
            <div className="text-wrapper-51">Due</div>
            <img className="due-icons" alt="Due icons" src="/img/est-total-icons.svg" />
          </div>
          <div className="frame-35">
            <div className="text-wrapper-52">30 days ago</div>
          </div>
          <div className="frame-36">
            <div className="text-wrapper-53">6 days ago</div>
          </div>
          <div className="frame-37">
            <div className="text-wrapper-54">30 days ago</div>
          </div>
          <div className="frame-38">
            <div className="text-wrapper-55">30 days ago</div>
          </div>
          <div className="frame-39">
            <div className="text-wrapper-56">30 days ago</div>
          </div>
          <div className="frame-40">
            <div className="text-wrapper-57">30 days ago</div>
          </div>
          <div className="frame-41">
            <div className="text-wrapper-58">Car</div>
          </div>
          <div className="frame-42">
            <div className="text-wrapper-59">Audi</div>
          </div>
          <div className="frame-43">
            <div className="text-wrapper-60">Nissan</div>
          </div>
          <div className="frame-44">
            <div className="text-wrapper-61">Audi</div>
          </div>
          <div className="frame-45">
            <div className="text-wrapper-62">Audi</div>
          </div>
          <div className="frame-46">
            <div className="text-wrapper-63">Audi</div>
          </div>
          <div className="frame-47">
            <div className="text-wrapper-64">Audi</div>
          </div>
          <div className="frame-48">
            <div className="text-wrapper-65">No plate</div>
          </div>
          <div className="frame-49">
            <div className="text-wrapper-66">BC 3320</div>
          </div>
          <div className="frame-50">
            <div className="text-wrapper-67">BC 3320</div>
          </div>
          <div className="frame-51">
            <div className="text-wrapper-68">BC 3320</div>
          </div>
          <div className="frame-52">
            <div className="text-wrapper-69">BC 3320</div>
          </div>
          <div className="frame-53">
            <div className="text-wrapper-70">BC 3320</div>
          </div>
          <div className="frame-54">
            <div className="text-wrapper-71">BC 3320</div>
          </div>
          <div className="frame-55">
            <div className="text-wrapper-72">Approval</div>
            <img className="approval-icons" alt="Approval icons" src="/img/est-total-icons.svg" />
          </div>
          <div className="ellipse-wrapper">
            <div className="ellipse-4" />
          </div>
          <div className="frame-56">
            <div className="ellipse-5" />
          </div>
          <div className="frame-57">
            <div className="ellipse-6" />
          </div>
          <div className="frame-58">
            <div className="ellipse-7" />
          </div>
          <div className="frame-59">
            <div className="ellipse-8" />
          </div>
          <div className="frame-60">
            <div className="ellipse-9" />
          </div>
          <div className="frame-61">
            <div className="text-wrapper-73">Converted</div>
            <img className="converted-icons" alt="Converted icons" src="/img/est-total-icons.svg" />
          </div>
          <div className="frame-62">
            <div className="ellipse-10" />
          </div>
          <div className="frame-63">
            <div className="ellipse-11" />
          </div>
          <div className="frame-64">
            <div className="ellipse-12" />
          </div>
          <div className="frame-65">
            <div className="ellipse-13" />
          </div>
          <div className="frame-66">
            <div className="ellipse-14" />
          </div>
          <div className="frame-67">
            <div className="ellipse-15" />
          </div>
          <div className="frame-68">
            <div className="text-wrapper-74">Est Total</div>
            <img className="est-total-icons" alt="Est total icons" src="/img/est-total-icons.svg" />
          </div>
          <div className="frame-69">
            <div className="text-wrapper-75">$ 234.00</div>
          </div>
          <div className="frame-70">
            <div className="text-wrapper-76">$ 234.00</div>
          </div>
          <div className="frame-71">
            <div className="text-wrapper-77">$ 234.00</div>
          </div>
          <div className="frame-72">
            <div className="text-wrapper-78">$ 234.00</div>
          </div>
          <div className="frame-73">
            <div className="text-wrapper-79">$ 234.00</div>
          </div>
          <div className="frame-74">
            <div className="text-wrapper-80">$ 234.00</div>
          </div>
          <div className="frame-75">
            <div className="text-wrapper-81">Edit</div>
          </div>
          <div className="component-wrapper">
            <div className="group-wrapper">
              <img className="group" alt="Group" src="/img/group.png" />
            </div>
          </div>
          <div className="frame-76">
            <div className="img-wrapper">
              <img className="group-2" alt="Group" src="/img/group.png" />
            </div>
          </div>
          <div className="frame-77">
            <div className="component-3">
              <img className="group-3" alt="Group" src="/img/group.png" />
            </div>
          </div>
          <div className="frame-78">
            <div className="component-4">
              <img className="group-4" alt="Group" src="/img/group.png" />
            </div>
          </div>
          <div className="frame-79">
            <div className="component-5">
              <img className="group-5" alt="Group" src="/img/group.png" />
            </div>
          </div>
          <div className="frame-80">
            <div className="component-6">
              <img className="group-6" alt="Group" src="/img/group.png" />
            </div>
          </div>
          <div className="frame-81">
            <div className="text-wrapper-82">share</div>
          </div>
          <div className="frame-82">
            <div className="component-7">
              <img className="vector-3" alt="Vector" src="/img/vector-18.svg" />
            </div>
          </div>
          <div className="frame-83">
            <div className="component-8">
              <img className="vector-4" alt="Vector" src="/img/vector-18.svg" />
            </div>
          </div>
          <div className="frame-84">
            <div className="component-9">
              <img className="vector-5" alt="Vector" src="/img/vector-18.svg" />
            </div>
          </div>
          <div className="frame-85">
            <div className="component-10">
              <img className="vector-6" alt="Vector" src="/img/vector-18.svg" />
            </div>
          </div>
          <div className="frame-86">
            <div className="component-11">
              <img className="vector-7" alt="Vector" src="/img/vector-18.svg" />
            </div>
          </div>
          <div className="frame-87">
            <div className="component-12">
              <img className="vector-8" alt="Vector" src="/img/vector-18.svg" />
            </div>
          </div>
          <div className="frame-88">
            <div className="text-wrapper-83">Action</div>
          </div>
          <div className="frame-wrapper">
            <div className="frame-89">
              <div className="text-wrapper-84">Action</div>
              <img className="polygon" alt="Polygon" src="/img/polygon-6.svg" />
            </div>
          </div>
          <div className="frame-90">
            <div className="frame-91">
              <div className="text-wrapper-85">Action</div>
              <img className="polygon-2" alt="Polygon" src="/img/polygon-6.svg" />
            </div>
          </div>
          <div className="frame-92">
            <div className="frame-93">
              <div className="text-wrapper-86">Action</div>
              <img className="polygon-3" alt="Polygon" src="/img/polygon-6.svg" />
            </div>
          </div>
          <div className="frame-94">
            <div className="frame-95">
              <div className="text-wrapper-87">Action</div>
              <img className="polygon-4" alt="Polygon" src="/img/polygon-6.svg" />
            </div>
          </div>
          <div className="frame-96">
            <div className="frame-97">
              <div className="text-wrapper-88">Action</div>
              <img className="polygon-5" alt="Polygon" src="/img/polygon-6.svg" />
            </div>
          </div>
          <div className="frame-98">
            <div className="frame-99">
              <div className="text-wrapper-89">Action</div>
              <img className="polygon-6" alt="Polygon" src="/img/polygon-6.svg" />
            </div>
          </div>
          <div className="frame-100">
            <div className="frame-101">
              <img className="layer" alt="Layer" src="/img/layer-x0020-1.png" />
              <img className="layer-x" alt="Layer" src="/img/layer-x0020-1-1.png" />
            </div>
            <div className="frame-102">
              <div className="text-wrapper-90">Dashboard</div>
              <img className="dashboard-list" alt="Dashboard list" src="/img/income-list.svg" />
            </div>
            <div className="frame-103">
              <div className="text-wrapper-91">Job Card</div>
              <img className="job-card-list" alt="Job card list" src="/img/income-list.svg" />
            </div>
            <div className="group-7">
              <div className="frame-104">
                <div className="text-wrapper-92">Income</div>
                <img className="income-list" alt="Income list" src="/img/income-list.svg" />
              </div>
            </div>
            <div className="frame-105">
              <div className="text-wrapper-93">Expense</div>
              <img className="expense-list" alt="Expense list" src="/img/expense-list.svg" />
            </div>
            <div className="frame-106">
              <div className="text-wrapper-94">Accounting</div>
              <img className="accounting-list" alt="Accounting list" src="/img/accounting-list.png" />
            </div>
            <div className="frame-107">
              <div className="text-wrapper-95">Reports</div>
              <img className="reports-list" alt="Reports list" src="/img/reports-list.svg" />
            </div>
            <div className="frame-108">
              <div className="text-wrapper-96">Setting</div>
            </div>
            <div className="frame-109">
              <div className="text-wrapper-97">Search</div>
              <img className="search-icons" alt="Search icons" src="/img/search-icons.svg" />
            </div>
            <img className="frame-110" alt="Frame" src="/img/frame-48266.svg" />
            <div className="profile-wrapper">
              <img className="profile" alt="Profile" src="/img/profile.png" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
